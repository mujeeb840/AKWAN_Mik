package com.akwanmik.app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
